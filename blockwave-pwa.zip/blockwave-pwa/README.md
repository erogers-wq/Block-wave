# Blockwave — GitHub Pages PWA with a global leaderboard

```
your-repo/
├── index.html            the whole game (entry point — do not rename)
├── manifest.json
├── service-worker.js
├── supabase-setup.sql    run once in Supabase, not uploaded anywhere
└── icons/
    ├── apple-touch-icon-180.png
    ├── icon-192.png
    ├── icon-512.png
    └── icon-512-maskable.png
```

Commit these to your existing repository, keeping `index.html` at the same
place it is now. Nothing about how the site launches has changed: no build
step, no server, no framework. `icons/` must stay a subfolder.

---

## Architecture

```
GitHub Pages  →  Blockwave PWA  →  Supabase  →  every other player
```

Supabase is a hosted database with a REST API that browsers can call
directly, so a static site can have a real shared leaderboard with nothing
running on your computer.

---

## 1. Create the database project

1. Go to **supabase.com** and sign in (free tier is plenty).
2. **New project**. Give it a name, set a database password (you will not
   need it again), pick the region nearest you, and create it.
3. Wait about a minute for it to finish provisioning.

## 2. Create the leaderboard table

1. In the left sidebar open **SQL Editor → New query**.
2. Open `supabase-setup.sql`, copy the whole file, paste it in.
3. Press **Run**. It should report success.

That creates the `blockwave_scores` table, its indexes, and the security
rules in one go.

## 3. Security rules

The SQL above already sets them. For reference, Row Level Security is on and
the public `anon` key may only:

* **read** the board
* **insert** a row
* **update** a row

It cannot drop the table, read other Supabase tables, or touch your account.
Column limits reject absurd names, scores and levels. Because this is a
public game with no logins, anyone with the URL can submit a score — that is
the trade-off for having no sign-in. It is fine for friends and family.

## 4. Get your public configuration

1. **Project Settings → API**.
2. Copy the **Project URL** — looks like `https://abcdefgh.supabase.co`
3. Copy the **anon public** key — a long string starting `eyJ...`

> Copy the key labelled **anon / public** only.
> **Never** copy the `service_role` key. That one is a master key and must
> never appear in a repository. The anon key is designed to be public and is
> safe to commit.

## 5. Put the configuration into Blockwave

Open `index.html`, search for `SUPABASE_URL` (near the top of the script,
about two thirds down the file) and fill in the two lines:

```js
let SUPABASE_URL      = "https://abcdefgh.supabase.co";
let SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...";
```

Save. That is the only edit.

## 6. Upload to GitHub

**Web interface:** open your repository → **Add file → Upload files** → drag
in `index.html`, `manifest.json`, `service-worker.js` and the `icons` folder
→ **Commit changes**.

**Command line:**

```bash
git add index.html manifest.json service-worker.js icons
git commit -m "Blockwave: global leaderboard"
git push
```

GitHub Pages redeploys within a minute. Your existing Pages URL is unchanged.

**If you already had the app installed**, bump `CACHE_VERSION` in
`service-worker.js` (e.g. `blockwave-v3`) before committing, or the old
cached copy may keep loading.

## 7. Testing across phones

1. Open your Pages URL on your iPhone in Safari.
2. Menu → **PROGRESS** is not needed; on the home screen check the board
   header. It should read **ONLINE** in green once it has synced.
   Settings → Online play should say *"Live. Everyone playing shares one
   board."*
3. Set a name (required to play), play a game, let it end.
4. Open the same URL on a second phone, set a different name, play a game.
5. Both names should now appear on the same board on both phones.
   Standings refresh automatically every 10 minutes; Settings → Online play
   → **Sync** pulls immediately if you don't want to wait.
6. To confirm the data really is shared, look in Supabase under
   **Table Editor → blockwave_scores** — you should see one row per device.

---

## Adding it to an iPhone Home Screen

1. Open the Pages URL in **Safari**.
2. Tap **Share** → **Add to Home Screen** → **Add**.
3. Launch it from the icon. It opens full screen and plays with no signal.

---

## Where things are stored

| Data | Where |
|---|---|
| Best score, XP, level, prestige, themes, settings, name | `localStorage`, key `blockwave_save_v2`, on that device |
| Global leaderboard | Supabase — shared by everyone |

Your personal progress stays on your own phone, so family members each keep
their own save. Only the leaderboard is shared. If Supabase is unreachable
the game plays normally and shows a local board until it reconnects.
